# See https://docs.chef.io/workstation/config_rb/ for more information on knife configuration options

current_dir = File.dirname(__FILE__)
log_level                :info
log_location             STDOUT
node_name                "nikhil_007"
client_key               "#{current_dir}/nikhil_007.pem"
chef_server_url          "https://api.chef.io/organizations/101cc"
cookbook_path            ["#{current_dir}/../cookbooks"]
